package com.mamarik.daftarmuhasabi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mamarik.daftarmuhasabi.data.Transaction
import com.mamarik.daftarmuhasabi.data.TransactionType
import com.mamarik.daftarmuhasabi.ui.AccountingViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val viewModel: AccountingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AccountingApp(viewModel) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountingApp(viewModel: AccountingViewModel) {
    val allTransactions by viewModel.transactions.collectAsStateWithLifecycle()
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Transaction?>(null) }
    var filter by remember { mutableStateOf<TransactionType?>(null) }

    val filtered = remember(allTransactions, filter) {
        filter?.let { t -> allTransactions.filter { it.type == t } } ?: allTransactions
    }

    val income = allTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    val expense = allTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    val balance = income - expense

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("دفتر محاسبي", fontWeight = FontWeight.Bold) })
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { editing = null; showEditor = true },
                    text = { Text("إضافة حركة") }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize()
            ) {
                SummaryCard(balance, income, expense)
                Spacer(Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("الكل") })
                    FilterChip(selected = filter == TransactionType.INCOME, onClick = { filter = TransactionType.INCOME }, label = { Text("الوارد") })
                    FilterChip(selected = filter == TransactionType.EXPENSE, onClick = { filter = TransactionType.EXPENSE }, label = { Text("الصادر") })
                }

                Spacer(Modifier.height(12.dp))
                Text("سجل الحركات", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))

                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("لا توجد حركات حتى الآن")
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered, key = { it.id }) { tx ->
                            TransactionCard(
                                tx,
                                onEdit = { editing = tx; showEditor = true },
                                onDelete = { viewModel.delete(tx) }
                            )
                        }
                        item { Spacer(Modifier.height(88.dp)) }
                    }
                }
            }
        }

        if (showEditor) {
            TransactionEditor(
                initial = editing,
                onDismiss = { showEditor = false },
                onSave = { tx ->
                    if (tx.id == 0L) viewModel.add(tx) else viewModel.update(tx)
                    showEditor = false
                }
            )
        }
    }
}

@Composable
fun SummaryCard(balance: Double, income: Double, expense: Double) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("الرصيد الحالي", style = MaterialTheme.typography.titleMedium)
            Text(formatMoney(balance), fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("إجمالي الوارد"); Text(formatMoney(income), fontWeight = FontWeight.Bold) }
                Column(horizontalAlignment = Alignment.End) { Text("إجمالي الصادر"); Text(formatMoney(expense), fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun TransactionCard(tx: Transaction, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(tx.title, fontWeight = FontWeight.Bold)
                    val extra = listOf(tx.party, tx.category).filter { it.isNotBlank() }.joinToString(" • ")
                    if (extra.isNotBlank()) Text(extra, style = MaterialTheme.typography.bodySmall)
                    Text(formatDate(tx.createdAt), style = MaterialTheme.typography.bodySmall)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        (if (tx.type == TransactionType.INCOME) "+ " else "- ") + formatMoney(tx.amount),
                        fontWeight = FontWeight.Bold
                    )
                    Text(if (tx.type == TransactionType.INCOME) "وارد" else "صادر")
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onEdit) { Text("تعديل") }
                TextButton(onClick = onDelete) { Text("حذف") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionEditor(initial: Transaction?, onDismiss: () -> Unit, onSave: (Transaction) -> Unit) {
    var type by remember { mutableStateOf(initial?.type ?: TransactionType.INCOME) }
    var amount by remember { mutableStateOf(initial?.amount?.toString() ?: "") }
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var party by remember { mutableStateOf(initial?.party ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "") }
    var paymentMethod by remember { mutableStateOf(initial?.paymentMethod ?: "نقدي") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    val amountValue = amount.toDoubleOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة حركة" else "تعديل الحركة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == TransactionType.INCOME, onClick = { type = TransactionType.INCOME }, label = { Text("وارد") })
                    FilterChip(selected = type == TransactionType.EXPENSE, onClick = { type = TransactionType.EXPENSE }, label = { Text("صادر") })
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(title, { title = it }, label = { Text("البيان") }, singleLine = true)
                OutlinedTextField(party, { party = it }, label = { Text("العميل / المورد") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("التصنيف") }, singleLine = true)
                OutlinedTextField(paymentMethod, { paymentMethod = it }, label = { Text("طريقة الدفع") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, maxLines = 3)
            }
        },
        confirmButton = {
            Button(
                enabled = amountValue != null && amountValue > 0 && title.isNotBlank(),
                onClick = {
                    onSave(
                        Transaction(
                            id = initial?.id ?: 0,
                            type = type,
                            amount = amountValue ?: 0.0,
                            title = title.trim(),
                            party = party.trim(),
                            category = category.trim(),
                            paymentMethod = paymentMethod.trim(),
                            notes = notes.trim(),
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                    )
                }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

fun formatMoney(value: Double): String {
    val nf = NumberFormat.getNumberInstance(Locale("ar", "LY"))
    nf.maximumFractionDigits = 2
    return "${nf.format(value)} د.ل"
}

fun formatDate(value: Long): String =
    SimpleDateFormat("dd/MM/yyyy - HH:mm", Locale("ar", "LY")).format(Date(value))
