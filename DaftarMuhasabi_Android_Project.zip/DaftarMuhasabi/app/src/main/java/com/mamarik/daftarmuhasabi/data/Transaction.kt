package com.mamarik.daftarmuhasabi.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { INCOME, EXPENSE }

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: TransactionType,
    val amount: Double,
    val title: String,
    val party: String = "",
    val category: String = "",
    val paymentMethod: String = "نقدي",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
