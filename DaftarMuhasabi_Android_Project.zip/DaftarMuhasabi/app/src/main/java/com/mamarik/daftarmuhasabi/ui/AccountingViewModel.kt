package com.mamarik.daftarmuhasabi.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mamarik.daftarmuhasabi.data.AppDatabase
import com.mamarik.daftarmuhasabi.data.Transaction
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AccountingViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getInstance(application).transactionDao()

    val transactions = dao.observeAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    fun add(transaction: Transaction) = viewModelScope.launch { dao.insert(transaction) }
    fun update(transaction: Transaction) = viewModelScope.launch { dao.update(transaction) }
    fun delete(transaction: Transaction) = viewModelScope.launch { dao.delete(transaction) }
}
