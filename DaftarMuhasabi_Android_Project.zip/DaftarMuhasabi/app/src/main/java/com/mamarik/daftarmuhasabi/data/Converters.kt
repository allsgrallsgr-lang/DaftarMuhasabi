package com.mamarik.daftarmuhasabi.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromType(value: TransactionType): String = value.name

    @TypeConverter
    fun toType(value: String): TransactionType = TransactionType.valueOf(value)
}
